# SMASH ARENA — Multiplayer prototype

A Roblox-inspired 3D arena brawler prototype using Three.js in the browser and Socket.IO for real-time multiplayer.

## Run locally
1. Install Node.js 18 or newer.
2. Extract this ZIP.
3. Open a terminal in the extracted `smash_arena_multiplayer` folder.
4. Run `npm install`
5. Run `npm start`
6. Open http://localhost:3000

To test multiplayer on one computer, open the page in two different browser tabs.

## Controls
- WASD / Arrow keys: move
- Space: jump
- Click / tap the punch button: punch
- Mobile: on-screen joystick, jump and punch

## Important
This is a playable prototype, not a finished commercial release. Multiplayer requires the Node.js server to stay online. A static HTML upload by itself will NOT provide online multiplayer. Deploy this Node app to a service that supports persistent Node.js processes and WebSockets (for example, Render or Railway), then use the deployed URL for testing.

Before submitting to CrazyGames, check its current SDK, multiplayer, privacy, and publishing requirements. Add the CrazyGames SDK and any required consent / ad integration only after the game is stable. There is no guarantee of acceptance or revenue.
