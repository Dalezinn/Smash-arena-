const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const PORT = process.env.PORT || 3000;
app.use(express.static("public"));
app.get("/health", (_, res) => res.json({ ok: true }));

const MAX_PLAYERS = 12;
const ARENA_RADIUS = 13.5;
const players = new Map();
let phase = "lobby";
let countdown = 10;
let roundNumber = 0;
let roundTimer = 0;
let winnerName = "";

const names = ["Pixel", "Comet", "Noodle", "Turbo", "Bubbles", "Rex", "Mochi", "Zippy", "Nova", "Waffle", "Dash", "Kiwi"];
const colors = ["#36d9ff", "#ff6384", "#ffd166", "#9b8cff", "#65e6a5", "#ff985e", "#f28cff", "#b6e05b", "#6f9bff", "#ffdc78", "#ff78b7", "#79f0dc"];

function publicState() {
  return {
    phase, countdown: Math.max(0, Math.ceil(countdown)), roundNumber, winnerName,
    players: [...players.values()].map(p => ({
      id: p.id, name: p.name, color: p.color, x: p.x, y: p.y, z: p.z,
      vx: p.vx, vy: p.vy, vz: p.vz, alive: p.alive, wins: p.wins,
      punching: p.punchVisual > 0
    }))
  };
}
function spawn(p, index) {
  const a = (index / Math.max(1, players.size)) * Math.PI * 2;
  const r = 4 + (index % 2) * 2;
  p.x = Math.cos(a) * r; p.z = Math.sin(a) * r;
  p.y = 0.95; p.vx = 0; p.vy = 0; p.vz = 0;
  p.alive = true; p.punchCd = 0; p.punchVisual = 0; p.invuln = 1.2;
}
function beginRound() {
  roundNumber++;
  phase = "playing";
  countdown = 0;
  winnerName = "";
  let i = 0;
  for (const p of players.values()) spawn(p, i++);
  io.emit("notice", `ROUND ${roundNumber} — FIGHT!`);
}
function finishRound(winner) {
  phase = "results";
  winnerName = winner ? winner.name : "Nobody";
  if (winner) winner.wins++;
  roundTimer = 5;
  io.emit("notice", winner ? `${winner.name} wins the round!` : "Nobody won that round!");
}
io.on("connection", socket => {
  if (players.size >= MAX_PLAYERS) {
    socket.emit("full");
    socket.disconnect(true);
    return;
  }
  const p = {
    id: socket.id,
    name: names[Math.floor(Math.random() * names.length)] + Math.floor(Math.random() * 90 + 10),
    color: colors[Math.floor(Math.random() * colors.length)],
    x: 0, y: 0.95, z: 0, vx: 0, vy: 0, vz: 0,
    alive: phase !== "playing", wins: 0,
    input: { x: 0, z: 0 }, punchCd: 0, punchVisual: 0, invuln: 0
  };
  players.set(socket.id, p);
  if (phase === "playing") p.alive = false;
  else spawn(p, players.size - 1);
  socket.emit("welcome", { id: p.id, name: p.name, maxPlayers: MAX_PLAYERS });
  io.emit("state", publicState());

  socket.on("input", data => {
    if (!data || !p.alive || phase !== "playing") return;
    const x = Number(data.x) || 0, z = Number(data.z) || 0;
    const len = Math.hypot(x, z) || 1;
    p.input.x = Math.max(-1, Math.min(1, x / len));
    p.input.z = Math.max(-1, Math.min(1, z / len));
    if (data.jump && p.y <= 1.02) p.vy = 8.2;
  });
  socket.on("punch", () => {
    if (!p.alive || phase !== "playing" || p.punchCd > 0) return;
    p.punchCd = 0.65;
    p.punchVisual = 0.22;
    for (const other of players.values()) {
      if (other.id === p.id || !other.alive || other.invuln > 0) continue;
      const dx = other.x - p.x, dz = other.z - p.z;
      const d = Math.hypot(dx, dz);
      if (d < 3.25 && d > 0.01 && Math.abs(other.y - p.y) < 2.5) {
        const force = 10.5 + Math.max(0, 3.25 - d) * 1.5;
        other.vx += dx / d * force;
        other.vz += dz / d * force;
        other.vy = Math.max(other.vy, 2.2);
        other.invuln = 0.25;
        p.vx -= dx / d * 1.2;
        p.vz -= dz / d * 1.2;
        io.emit("hit", { x: other.x, y: other.y, z: other.z });
      }
    }
  });
  socket.on("disconnect", () => {
    players.delete(socket.id);
    io.emit("state", publicState());
  });
});

let last = Date.now();
setInterval(() => {
  const now = Date.now();
  const dt = Math.min(0.04, (now - last) / 1000);
  last = now;

  if (phase === "lobby") {
    if (players.size >= 1) {
      countdown -= dt;
      if (countdown <= 0) beginRound();
    } else countdown = 10;
  } else if (phase === "playing") {
    for (const p of players.values()) {
      if (!p.alive) continue;
      p.punchCd = Math.max(0, p.punchCd - dt);
      p.punchVisual = Math.max(0, p.punchVisual - dt);
      p.invuln = Math.max(0, p.invuln - dt);
      const accel = 27;
      p.vx += p.input.x * accel * dt;
      p.vz += p.input.z * accel * dt;
      const drag = Math.pow(0.90, dt * 30);
      p.vx *= drag; p.vz *= drag;
      const speed = Math.hypot(p.vx, p.vz);
      if (speed > 10) { p.vx *= 10 / speed; p.vz *= 10 / speed; }
      p.x += p.vx * dt; p.z += p.vz * dt;
      p.vy -= 22 * dt; p.y += p.vy * dt;
      if (p.y < 0.95) { p.y = 0.95; p.vy = 0; }
      if (Math.hypot(p.x, p.z) > ARENA_RADIUS + 1.5 || p.y < -3) {
        p.alive = false;
        io.emit("notice", `${p.name} fell out!`);
      }
    }
    const alive = [...players.values()].filter(p => p.alive);
    if (alive.length <= 1 && players.size > 0) finishRound(alive[0]);
  } else if (phase === "results") {
    roundTimer -= dt;
    if (roundTimer <= 0) {
      phase = "lobby";
      countdown = 8;
      for (const p of players.values()) { p.alive = true; spawn(p, [...players.keys()].indexOf(p.id)); }
    }
  }
  io.emit("state", publicState());
}, 1000 / 30);

server.listen(PORT, () => console.log(`SMASH ARENA running on port ${PORT}`));
